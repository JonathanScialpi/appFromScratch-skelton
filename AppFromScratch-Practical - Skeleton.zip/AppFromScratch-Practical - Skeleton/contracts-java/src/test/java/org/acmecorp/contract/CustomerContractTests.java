package org.acmecorp.contract;

import net.corda.core.contracts.Amount;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.CordaX500Name;
import net.corda.testing.core.TestIdentity;
import net.corda.testing.node.MockServices;
import org.acmecorp.state.Address;
import org.acmecorp.state.CustomerState;
import org.acmecorp.state.PropertyType;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Currency;
import java.util.List;
import static net.corda.testing.node.NodeTestUtils.ledger;

public class CustomerContractTests {


    static private MockServices ledgerServices = new MockServices(Arrays.asList("org.acmecorp.contract"));
    static Amount<Currency> defaultPropValuation = new Amount<Currency>((long) 100000, Currency.getInstance("USD"));
    static Amount<Currency> defaultBuyerRangeFrom = new Amount<Currency>((long) 90000, Currency.getInstance("USD"));
    static Amount<Currency> defaultBuyerRangeTo = new Amount<Currency>((long) 120000, Currency.getInstance("USD"));
    static Address defaultPropAdd1 = new Address("1 Property Street");
    static Address defaultBuyerAdd1 = new Address("1 Buyer Street");

    static PropertyType propTypeDef1= new PropertyType(defaultPropAdd1, defaultPropValuation);
    List<PropertyType> defaultProperties = Arrays.asList(propTypeDef1);

    static int MIN_BEDROOMS = 3;
    static int MAX_BEDROOMS = 6;
    static String PCODE_AREA = "90210";

    private TestIdentity alice = new TestIdentity(new CordaX500Name("Alice Ltd", "London", "GB"));
    private TestIdentity bob = new TestIdentity(new CordaX500Name("Bob Inc", "New York", "US"));
    private TestIdentity charlie = new TestIdentity(new CordaX500Name("Charlie SA", "Paris", "FR"));
    private TestIdentity dave = new TestIdentity(new CordaX500Name("Dave plc", "London", "GB"));
    @Test
    public void BuyerAndAgentMustBeDifferent() {
        ledgerServices = new MockServices(Arrays.asList("org.acmecorp.contract"));
        PropertyType prop = new PropertyType(defaultPropAdd1, defaultPropValuation);
        CustomerState.CustomerStatus customerStatus = CustomerState.CustomerStatus.REGISTERED;
        List<PropertyType> properties = Arrays.asList(prop);
        Address buyerAddress = new Address("1 Buyer Street");
        CustomerState csProposedFails = new CustomerState(
                properties,
                alice.getParty(),
                alice.getParty(),
                buyerAddress,
                defaultBuyerRangeFrom,
                defaultBuyerRangeTo,
                MIN_BEDROOMS, MAX_BEDROOMS,
                PCODE_AREA,
                0,
                "",
                customerStatus
                );

        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedFails);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Register());
                return tx.failsWith("The buyer and the agent cannot be the same entity.");
            });
            return null;
        });

        CustomerState csProposedSucceeds= new CustomerState(
                properties,
                alice.getParty(),
                bob.getParty(),
                buyerAddress,
                defaultBuyerRangeFrom,
                defaultBuyerRangeTo,
                MIN_BEDROOMS, MAX_BEDROOMS,
                PCODE_AREA,
                0,
                "",
                customerStatus
        );

        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedSucceeds);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Register());
                return tx.verifies();
            });
            return null;
        });
    }

    /**
     * On registration we cannot accept those which have no properties of interest
     */
    @Test
    public void PropertyMustBeIncluded() {

        List<PropertyType> properties = new ArrayList<PropertyType>();
        CustomerState.CustomerStatus customerStatus = CustomerState.CustomerStatus.REGISTERED;
        CustomerState csProposedFails = new CustomerState(
                properties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                MIN_BEDROOMS, MAX_BEDROOMS, PCODE_AREA, 0,"", customerStatus);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedFails);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Register());
                return tx.failsWith("A property must be included in when registering.");
            });
            return null;
        });
    }

    @Test
    public void OnRegistrationStatus() {
        ledgerServices = new MockServices(Arrays.asList("org.acmecorp.contract"));
        PropertyType prop = new PropertyType(defaultPropAdd1, defaultPropValuation);

        CustomerState.CustomerStatus customerStatus = CustomerState.CustomerStatus.REGISTERED;
        PropertyType pType = new PropertyType(defaultPropAdd1, defaultPropValuation);

        List<PropertyType> properties = Arrays.asList(pType);
        Address buyerAddress = new Address("1 Buyer Street");
        UniqueIdentifier linearId = new UniqueIdentifier();
        // Add a min bedrooms of 0 and a postcode area of "", should raise an error
        CustomerState csProposedFails = new CustomerState(
                properties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                MIN_BEDROOMS, MAX_BEDROOMS, "", 0,"", customerStatus);

        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedFails);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Register());
                return tx.verifies();
            });
            return null;
        });
    }
    @Test
    public void StateConsistency() {
        /**
         * Checks linearIds are not changing between state transitions
         * We need to accommodate moving states across the evolution and testing
         */
        UniqueIdentifier linearId1 = new UniqueIdentifier();
        ledgerServices = new MockServices(Arrays.asList("org.acmecorp.contract"));
        CustomerState csProposed1 = new CustomerState(
                CustomerState.CustomerStatus.REGISTERED, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 0,"", linearId1);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposed1);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Register());
                return tx.verifies();
            });
            return null;
        });
        UniqueIdentifier linearId2 = new UniqueIdentifier();
        CustomerState csProposed2 = new CustomerState(
                CustomerState.CustomerStatus.PROFILED, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 5,"", linearId2);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.input(CustomerContract.CUSTOMER_CONTRACT_ID, csProposed1);
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposed2);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Profile());
                return tx.verifies();
            });
            return null;
        });
        UniqueIdentifier linearId3 = new UniqueIdentifier();
        CustomerState csProposed3 = new CustomerState(
                CustomerState.CustomerStatus.UNREGISTERED, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 5,"", linearId3);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.input(CustomerContract.CUSTOMER_CONTRACT_ID, csProposed2);
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposed3);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Unregister());
                return tx.verifies();
            });
            return null;
        });
        UniqueIdentifier linearId4 = new UniqueIdentifier();
        CustomerState csProposed4 = new CustomerState(
                CustomerState.CustomerStatus.ARCHIVE, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 5,"", linearId4);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.input(CustomerContract.CUSTOMER_CONTRACT_ID, csProposed3);
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposed4);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Archive());
                return tx.verifies();
            });
            return null;
        });
    }

    public void SignerConsistency() {
        ledgerServices = new MockServices(Arrays.asList("org.acmecorp.contract"));
        UniqueIdentifier linearId1 = new UniqueIdentifier();
        // Test 1
        CustomerState csProposedReg1 = new CustomerState(
                CustomerState.CustomerStatus.REGISTERED, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 0, "", linearId1);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedReg1);
                tx.command(Arrays.asList(alice.getPublicKey(), bob.getPublicKey()), new CustomerContract.Commands.Register());
                return tx.verifies();
            });
            return null;
        });
        //Test
        UniqueIdentifier linearId2 = new UniqueIdentifier();
        CustomerState csProposedReg2 = new CustomerState(
                CustomerState.CustomerStatus.REGISTERED, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 0, "", linearId2);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedReg1);
                tx.command(Arrays.asList(alice.getPublicKey()), new CustomerContract.Commands.Register());
                return tx.failsWith("Both the buyer and agent must sign.");
            });
            return null;
        });
//Test
        UniqueIdentifier linearId3 = new UniqueIdentifier();
        CustomerState csProposedProf1 = new CustomerState(
                CustomerState.CustomerStatus.REGISTERED, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 0, "", linearId3);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.input(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedReg2);
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedProf1);
                tx.command(Arrays.asList(alice.getPublicKey()), new CustomerContract.Commands.Profile());
                return tx.failsWith("The agent must sign.");
            });
            return null;
        });
        UniqueIdentifier linearId = new UniqueIdentifier();
        //Test
        CustomerState csProposedProf2 = new CustomerState(
                CustomerState.CustomerStatus.REGISTERED, defaultProperties, alice.getParty(), bob.getParty(),
                defaultBuyerAdd1, defaultBuyerRangeFrom, defaultBuyerRangeTo,
                3, MAX_BEDROOMS, "90210", 0, "", linearId);
        ledger(ledgerServices, l -> {
            l.transaction(tx -> {
                tx.input(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedReg2);
                tx.output(CustomerContract.CUSTOMER_CONTRACT_ID, csProposedProf1);
                tx.command(Arrays.asList(bob.getPublicKey()), new CustomerContract.Commands.Profile());
                return tx.verifies();
            });
            return null;
        });
    }
}
