package com.example.contract;

import com.example.state.IOUState;
import com.google.common.collect.ImmutableList;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.CordaX500Name;
import net.corda.testing.core.TestIdentity;
import net.corda.testing.node.MockServices;
import net.corda.testing.node.NodeTestUtils;
import org.junit.Test;

import static java.util.Arrays.asList;

public class IOUContractTests {
    static private final MockServices ledgerServices = new MockServices(asList("com.example.contract"));
    static private final TestIdentity megaCorp = new TestIdentity(new CordaX500Name("MegaCorp", "London", "GB"));
    static private final TestIdentity miniCorp = new TestIdentity(new CordaX500Name("MiniCorp", "London", "GB"));
    static private final int iouValue = 1;

    /**
     * Example Contract Test
     */
    @Test
    public void transactionMustIncludeCreateCommand() {
        NodeTestUtils.ledger(ledgerServices, (ledger -> {
            ledger.transaction(tx -> {
                tx.output(IOUContract.ID, new IOUState(iouValue, miniCorp.getParty(), megaCorp.getParty(), new UniqueIdentifier()));
                tx.fails();
                tx.command(ImmutableList.of(megaCorp.getPublicKey(), miniCorp.getPublicKey()), new IOUContract.Commands.Create());
                tx.verifies();
                return null;
            });
            return null;
        }));
    }

    /**
     * TO COMPLETE: transactionMustHaveNoInputs()
     */
    @Test
    public void transactionMustHaveNoInputs() {

    }

    /**
     * TO COMPLETE: transactionMustHaveOneOutput()
     */
    @Test
    public void transactionMustHaveOneOutput() {

    }

    /**
     * TO COMPLETE: lenderMustSignTransaction()
     */
    @Test
    public void lenderMustSignTransaction() {

    }

    /**
     * TO COMPLETE: borrowerMustSignTransaction()
     */
    @Test
    public void borrowerMustSignTransaction() {

    }

    /**
     * TO COMPLETE: lenderIsNotBorrower()
     */
    @Test
    public void lenderIsNotBorrower() {

    }

    /**
     * TO COMPLETE: cannotCreateNegativeValueIOUs()
     */
    @Test
    public void cannotCreateNegativeValueIOUs() {

    }
}