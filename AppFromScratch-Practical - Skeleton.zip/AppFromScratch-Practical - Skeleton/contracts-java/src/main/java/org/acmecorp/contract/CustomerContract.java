package org.acmecorp.contract;

import com.example.helpers.*;
import net.corda.core.contracts.CommandData;
import net.corda.core.contracts.CommandWithParties;
import net.corda.core.contracts.Contract;
import net.corda.core.contracts.TypeOnlyCommandData;
import net.corda.core.transactions.LedgerTransaction;
import org.acmecorp.state.CustomerState;
import org.jetbrains.annotations.NotNull;
import static net.corda.core.contracts.ContractsDSL.requireSingleCommand;
import static net.corda.core.contracts.ContractsDSL.requireThat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CustomerContract implements Contract {

    public static final String CUSTOMER_CONTRACT_ID = "org.acmecorp.contract.CustomerContract";
    public interface  Commands  extends CommandData {
        class Register extends TypeOnlyCommandData implements Commands{}
        class Profile extends TypeOnlyCommandData implements Commands{}
        class Unregister extends TypeOnlyCommandData implements Commands{}
        class Archive extends TypeOnlyCommandData implements Commands{}

    }
    @Override
    public void verify(@NotNull LedgerTransaction tx) throws IllegalArgumentException {
        verifyPathConstraints(tx, CustomerState.class);
        verifyUniversalConstraints(tx);
        verifyStatusConstraints(tx);
        verifyLinearIDConstraints(tx);
        verifySigningConstraints(tx);
        verifyCommandConstraints(tx);
    }

    public void verifyPathConstraints(@NotNull LedgerTransaction tx, Class CustomerState) {
        List<CustomerState> states = tx.inputsOfType(CustomerState.class);
        List<PathConstraint<StatusState>> allowedPaths = new ArrayList<>();
        final CommandWithParties<Commands> command=requireSingleCommand(tx.getCommands(),Commands.class);
        Status inputStatus = ContractUtilsKt.requireSingleInputStatus(tx, CustomerState.class);
        Path txPath = ContractUtilsKt.getPath(tx, CustomerState.class, command.getValue());
        for (CustomerState s : states) {
            Set<AdditionalStatesConstraint> ascs = new HashSet<>();
            if (s.getStatus().equals(org.acmecorp.state.CustomerState.CustomerStatus.REGISTERED)) {
                PathConstraint pc1 = new PathConstraint(command.getValue(), CustomerStatus.REGISTERED, new MultiplicityConstraint(),
                        new MultiplicityConstraint(), ascs);
                PathConstraint pc2 = new PathConstraint(command.getValue(), CustomerStatus.PROFILED, new MultiplicityConstraint(),
                        new MultiplicityConstraint(), ascs);
                allowedPaths.add(pc1);
                allowedPaths.add(pc2);
            }
            if (s.getStatus().equals(org.acmecorp.state.CustomerState.CustomerStatus.PROFILED)) {
                PathConstraint pc1 = new PathConstraint(command.getValue(), org.acmecorp.state.CustomerState.CustomerStatus.PROFILED, new MultiplicityConstraint(),
                        new MultiplicityConstraint(), ascs);
                PathConstraint pc2 = new PathConstraint(command.getValue(), CustomerStatus.UNREGISTERED, new MultiplicityConstraint(),
                        new MultiplicityConstraint(), ascs);
                allowedPaths.add(pc1);
                allowedPaths.add(pc2);
            }
            if (s.getStatus().equals(CustomerStatus.UNREGISTERED)) {
                PathConstraint pc1 = new PathConstraint(command.getValue(), CustomerStatus.UNREGISTERED, new MultiplicityConstraint(),
                        new MultiplicityConstraint(), ascs);
                PathConstraint pc2 = new PathConstraint(command.getValue(), CustomerStatus.ARCHIVE, new MultiplicityConstraint(),
                        new MultiplicityConstraint(), ascs);
                allowedPaths.add(pc1);
                allowedPaths.add(pc2);
            }
            if (s.getStatus().equals(CustomerStatus.ARCHIVE)) {
                PathConstraint pc = new PathConstraint(command.getValue(), CustomerStatus.ARCHIVE, new MultiplicityConstraint(), new MultiplicityConstraint(), ascs);
                allowedPaths.add(pc);
            }
            requireThat(require -> {
                require.using("txPath must be allowed by PathConstraints for InputStatus "+inputStatus, ContractUtilsKt.verifyPath(txPath, allowedPaths) );
                return null;
            });

        }
    }
    public void verifyUniversalConstraints(@NotNull LedgerTransaction tx) {
        List<CustomerState> states = tx.inputsOfType(CustomerState.class);
        states.addAll(tx.outputsOfType(CustomerState.class));
        for (CustomerState s : states) {
            requireThat(require -> {
                require.using("The buyer and the agent cannot be the same entity.", s.getBuyer()!=s.getAgent());
                require.using("A property must be included in when registering.", s.getProperties().size() > 0);
                return null;

            });
        }
    }
    public void verifyLinearIDConstraints(@NotNull LedgerTransaction tx) {
        List<CustomerState> inputStates = tx.inputsOfType(CustomerState.class);
        List<CustomerState> outputStates = tx.outputsOfType(CustomerState.class);
        requireThat(require -> {
            require.using("When using LinearStates there should be a maximum of one Primary input state.", inputStates.size() <= 1);
            require.using("When using LinearStates there should be a maximum of one Primary output state.", outputStates.size() <= 1);
            final CommandWithParties<Commands> command = requireSingleCommand(tx.getCommands(), Commands.class);
            if (command.getValue() instanceof Commands.Profile || command.getValue() instanceof Commands.Unregister || command.getValue() instanceof Commands.Archive) {
                require.using("The LinearIDs must not be changed for this state.", (inputStates.size() == 1 && outputStates.size() == 1) &&
                        (inputStates.get(0).getLinearId() == outputStates.get(0).getLinearId()));
            }
            return null;
        });
    }

    public void verifySigningConstraints(@NotNull LedgerTransaction tx) {
        final CustomerState inputState;

        if (tx.inputsOfType(CustomerState.class).size() >0) {
            inputState=tx.inputsOfType(CustomerState.class).get(0);
        }

        final CustomerState  outputState = tx.outputsOfType(CustomerState.class).get(0);


        final CommandWithParties<Commands> command=requireSingleCommand(tx.getCommands(),Commands.class);

        requireThat(require -> {
            if(command.getValue() instanceof Commands.Register) {
                require.using("Both the buyer and agent must sign.",command.getSigners().contains(outputState.getAgent().getOwningKey())
                        && command.getSigners().contains(outputState.getBuyer().getOwningKey()));
            }
            if(command.getValue() instanceof Commands.Profile) {
                require.using("The agent must sign.",command.getSigners().contains(outputState.getAgent().getOwningKey()));
            }
            if(command.getValue() instanceof Commands.Unregister) {
                require.using("The buyer must sign.",command.getSigners().contains(outputState.getBuyer().getOwningKey()));
            }
            if(command.getValue() instanceof Commands.Archive) {
                require.using("The agent must sign.",command.getSigners().contains(outputState.getAgent().getOwningKey()));
            }
            return null;
        });

    }
    public void verifyCommandConstraints(@NotNull LedgerTransaction tx) {

    }
    public void verifyStatusConstraints(@NotNull LedgerTransaction tx) {
        // Determine all the states
        List<CustomerState> states = tx.inputsOfType(CustomerState.class);
        states.addAll(tx.outputsOfType(CustomerState.class));
        for (CustomerState s : states) {
            if (s.equals(CustomerState.CustomerStatus.REGISTERED)) {
                requireThat(require -> {
                   require.using("When status is registered, all fields except quality and reason must be provided.",
                           !s.getPostCodeArea().equals("")
                           );
                   return null;

                });
            }
            if (s.equals(CustomerState.CustomerStatus.PROFILED)) {

            }
            if (s.equals(CustomerState.CustomerStatus.UNREGISTERED)) {

            }
            if (s.equals(CustomerState.CustomerStatus.ARCHIVE)) {

            }

        }
    }
}
