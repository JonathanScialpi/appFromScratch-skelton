package org.acmecorp.state;

import net.corda.core.serialization.CordaSerializable;

@CordaSerializable
public class Address {
    private String line1;
    public Address(String line1) {
        this.line1 = line1;
    }
}
