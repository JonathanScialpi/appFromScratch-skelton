package org.acmecorp.state;

import net.corda.core.contracts.Amount;
import net.corda.core.serialization.CordaSerializable;

import java.util.Currency;

@CordaSerializable
public class PropertyType {
    private Address address;
    private Amount<Currency> valuation;


    public PropertyType(Address address, Amount<Currency> valuation) {
        this.address = address;
        this.valuation = valuation;
    }
    public Address getAddress() {
        return address;
    }

    public Amount<Currency> getValuation() {
        return valuation;
    }

}

