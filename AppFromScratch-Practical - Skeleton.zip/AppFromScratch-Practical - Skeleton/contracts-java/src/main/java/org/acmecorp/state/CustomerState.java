package org.acmecorp.state;

import com.example.helpers.Status;
import com.example.helpers.StatusState;
import net.corda.core.contracts.Amount;
import net.corda.core.contracts.BelongsToContract;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.serialization.ConstructorForDeserialization;
import org.acmecorp.contract.CustomerContract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Currency;
import java.util.List;

@BelongsToContract(CustomerContract.class)
public class CustomerState implements StatusState, ContractState {
    private final CustomerStatus customerStatus;
    private final List<PropertyType> properties;
    private final Party buyer;
    private final Party agent;
    private final Address address;
    private final Amount<Currency> rangeFrom;
    private final Amount<Currency> rangeTo;
    private final int minBedrooms;
    private final int maxBedrooms;
    private final String postCodeArea;
    private final int quality;
    private final String reason;
    private final UniqueIdentifier linearId;


    public List<PropertyType> getProperties() {
        return properties;
    }

    public Party getBuyer() {
        return buyer;
    }

    public Party getAgent() {
        return agent;
    }

    public Address getAddress() {
        return address;
    }

    public Amount<Currency> getRangeFrom() {
        return rangeFrom;
    }

    public UniqueIdentifier getLinearId() {
        return linearId;
    }

    public Amount<Currency> getRangeTo() {
        return rangeTo;
    }

    public int getMinBedrooms() {
        return minBedrooms;
    }

    public int getMaxBedrooms() {
        return maxBedrooms;
    }

    public String getPostCodeArea() {
        return postCodeArea;
    }

    public int getQuality() {
        return quality;
    }

    public String getReason() {
        return reason;
    }
    @ConstructorForDeserialization
    private CustomerState(CustomerStatus customerStatus, List<PropertyType> properties, Party buyer, Party agent, Address address, Amount<Currency> rangeFrom, Amount<Currency> rangeTo, int minBedrooms, int maxBedrooms, String postCodeArea, int quality, String reason, UniqueIdentifier linearId) {
        this.customerStatus = customerStatus;
        this.properties = properties;
        this.buyer = buyer;
        this.agent = agent;

        this.address = address;
        this.rangeFrom = rangeFrom;
        this.rangeTo = rangeTo;
        this.minBedrooms = minBedrooms;
        this.maxBedrooms = maxBedrooms;
        this.postCodeArea = postCodeArea;
        this.quality = quality;
        this.reason = reason;
        this.linearId = linearId;
    }

    public CustomerState(List<PropertyType> properties, Party buyer, Party agent, Address address, Amount<Currency> rangeFrom, Amount<Currency> rangeTo, int minBedrooms, int maxBedrooms, String postCodeArea, int quality, String reason, CustomerStatus customerStatus) {
        this(customerStatus, properties,
                buyer,
                agent,
                address,
                rangeFrom,
                rangeTo,
                minBedrooms,
                maxBedrooms,
                postCodeArea,
                quality,
                reason, new UniqueIdentifier());

    }
    @NotNull
    @Override
    public List<AbstractParty> getParticipants() {
        return null;
    }

    public CustomerStatus getCustomerStatus() {
        return customerStatus;
    }

    @Nullable
    @Override
    public Status getStatus() {
        return customerStatus;
    }

    public enum CustomerStatus implements Status {
        REGISTERED,
        PROFILED,
        UNREGISTERED,
        ARCHIVE;
    }
}
