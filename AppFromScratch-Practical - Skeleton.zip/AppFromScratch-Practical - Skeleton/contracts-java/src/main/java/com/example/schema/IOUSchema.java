package com.example.schema;

/**
 * The family of schemas for IOUState.
 */
public class IOUSchema { }