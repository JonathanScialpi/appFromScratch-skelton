package com.example.contract;

import net.corda.core.contracts.CommandData;
import net.corda.core.contracts.Contract;
import net.corda.core.contracts.TypeOnlyCommandData;
import net.corda.core.transactions.LedgerTransaction;
import org.jetbrains.annotations.NotNull;

public class DummyContract implements Contract  {
    public static final String DUMMY_CONTRACT_ID = "com.example.contract.DummyContract";

    public interface Commands extends CommandData {

        class Register extends TypeOnlyCommandData implements DummyContract.Commands {}
    }
    @Override
    public void verify(@NotNull LedgerTransaction tx) throws IllegalArgumentException {

    }
}
