package com.example.state;

import net.corda.core.contracts.LinearState;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.Party;
import net.corda.core.schemas.MappedSchema;
import net.corda.core.schemas.PersistentState;
import net.corda.core.schemas.QueryableState;
import org.jetbrains.annotations.NotNull;

import java.security.PublicKey;
import java.util.Arrays;
import java.util.List;

public class PayloadDeliveryState implements LinearState, QueryableState  {
    // uniqueIdentifier, initiator, receiverParties, payload, chainLength

    public final UniqueIdentifier uniqueIdentifier;
    public final AbstractParty initiator;
    public final AbstractParty receiverParty;
    public final String payload;
    public final int chainLength;
    public final List<PublicKey> keys;


    public PayloadDeliveryState(UniqueIdentifier uniqueIdentifier, Party initiator, Party receiverParty, String payload, int chainLength, List<PublicKey> keys) {
        this.uniqueIdentifier = uniqueIdentifier;
        this.initiator = initiator;
        this.receiverParty = receiverParty;
        this.payload = payload;
        this.chainLength = chainLength;

        this.keys = keys;
    }

    @NotNull
    @Override
    public UniqueIdentifier getLinearId() {
        return uniqueIdentifier;
    }

    @NotNull
    @Override
    public PersistentState generateMappedObject(@NotNull MappedSchema schema) {
        return null;
    }

    @NotNull
    @Override
    public Iterable<MappedSchema> supportedSchemas() {
        return null;
    }

    @NotNull
    @Override
    public List<AbstractParty> getParticipants() {

        return (List<AbstractParty>) Arrays.asList(initiator, receiverParty);
    }

    public int getChainLength() {
        return chainLength;
    }
    public String getPayload() {
        return payload;
    }

    public List<PublicKey> getKeys() {
        return null;
    }
}
