package com.example.state;

import com.example.contract.DummyContract;
import net.corda.core.contracts.BelongsToContract;
import net.corda.core.contracts.ContractState;
import net.corda.core.identity.AbstractParty;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@BelongsToContract(DummyContract.class)
public class DummyState implements ContractState {
    private final String field1;

    public String getField1() {
        return field1;
    }

    public DummyState(String field1) {
        this.field1 = field1;
    }

    @NotNull
    @Override
    public List<AbstractParty> getParticipants() {
        return null;
    }
}
