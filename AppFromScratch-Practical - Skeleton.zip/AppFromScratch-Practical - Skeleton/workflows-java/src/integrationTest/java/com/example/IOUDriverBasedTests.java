package com.example;

import com.example.flow.IOUFlow;
import com.example.state.IOUState;
import com.google.common.collect.ImmutableList;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.identity.CordaX500Name;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;
import net.corda.testing.core.TestIdentity;
import net.corda.testing.driver.DriverParameters;
import net.corda.testing.driver.NodeHandle;
import net.corda.testing.driver.NodeParameters;
import org.junit.Test;

import java.util.List;

import static net.corda.testing.driver.Driver.driver;
import static org.junit.Assert.assertEquals;

public class IOUDriverBasedTests {
    private final TestIdentity bankA = new TestIdentity(new CordaX500Name("BankA", "", "GB"));
    private final TestIdentity bankB = new TestIdentity(new CordaX500Name("BankB", "", "US"));

    @Test
    public void exampleTest() {
        driver(new DriverParameters().withIsDebug(true).withStartNodesInProcess(true), dsl -> {
            // This starts two nodes simultaneously with startNode, which returns a future that completes when the node
            // has completed startup. Then these are all resolved with getOrThrow which returns the NodeHandle list.
            try {
                NodeHandle partyAHandle = dsl.startNode(new NodeParameters().withProvidedName(bankA.getName())).get();
                NodeHandle partyBHandle = dsl.startNode(new NodeParameters().withProvidedName(bankB.getName())).get();
                Party partyA = partyAHandle.getNodeInfo().getLegalIdentities().get(0);
                Party partyB = partyBHandle.getNodeInfo().getLegalIdentities().get(0);

                SignedTransaction stx = partyAHandle.getRpc().startFlowDynamic(IOUFlow.Initiator.class, "arg1", "arg2").getReturnValue().get();
                // assert ...

            } catch (Exception e) {
                throw new RuntimeException("Caught exception during test", e);
            }
            return null;
        });
    }

    /** TO COMPLETE: verifyIouStateStoredInBothNodesVault() */
    @Test
    public void verifyIouStateStoredInBothNodesVault() {
    }

}
