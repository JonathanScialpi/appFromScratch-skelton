//package com.example.flow;
//
//import static net.corda.core.contracts.ContractsDSL.requireThat;
//
//import co.paralleluniverse.fibers.Suspendable;
//import com.example.state.PayloadDeliveryState;
//import net.corda.core.contracts.*;
//import net.corda.core.crypto.SecureHash;
//import net.corda.core.flows.*;
//import net.corda.core.identity.Party;
//import net.corda.core.transactions.SignedTransaction;
//import net.corda.core.utilities.ProgressTracker;
//
//@InitiatedBy(PayloadDelivery.class)
//public class PayloadDeliveryResponder extends FlowLogic<SignedTransaction> {
//
//	private FlowSession counterpartySession;
//
//	public PayloadDeliveryResponder(FlowSession counterpartySession) {
//		this.counterpartySession = counterpartySession;
//	}
//
//	@Suspendable
//	@Override
//	public SignedTransaction call() throws FlowException {
//
//		class SignTxFlow extends SignTransactionFlow {
//
//			private SignTxFlow(FlowSession initiatorFlow, ProgressTracker progressTracker) {
//				super(initiatorFlow, progressTracker);
//			}
//
//			@Override
//			protected void checkTransaction(SignedTransaction stx) {
//				requireThat(require -> {
//					ContractState output = stx.getTx().getOutputs().get(0).getData();
//					require.using("This must be a PayloadDeliveryState transaction", output instanceof PayloadDeliveryState);
//					Party notary = stx.getTx().getNotary();
//					require.using("Notary must not be null", notary != null);
//					return null;
//				});
//			}
//		}
//
//		System.out.println("PayloadDeliveryResponder------------");
//		//Sign Flow and ReceiveFinalityFlow
//		final SignTxFlow signTxFlow = new SignTxFlow(counterpartySession, SignTransactionFlow.Companion.tracker());
//		final SecureHash txId = subFlow(signTxFlow).getId();
//		final SignedTransaction transaction = subFlow(new ReceiveFinalityFlow(counterpartySession, txId));
//
//
//		//Start SinglePayload subflow
//		final PayloadDeliveryState previousState = (PayloadDeliveryState) transaction.getTx().getOutputs().get(0).getData();
//		int chainLength = previousState.getChainLength();
//
//		if (chainLength >= 1) {
//			Party initiator = getOurIdentity();
//			Party receiverParty = counterpartySession.getCounterparty();
//
//			//UniqueIdentifier uniqueIdentifier = new UniqueIdentifier();
//			PayloadDeliveryState state = new PayloadDeliveryState(previousState.getLinearId(), initiator, receiverParty, previousState.getPayload(), chainLength, keys);
//			subFlow(new SinglePayloadDelivery(initiator, receiverParty, state, txId));
//		}
//
//
//		return transaction;
//	}
//
//}
