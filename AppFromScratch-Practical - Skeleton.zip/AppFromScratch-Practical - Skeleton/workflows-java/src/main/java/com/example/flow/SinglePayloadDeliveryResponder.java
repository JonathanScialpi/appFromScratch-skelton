package com.example.flow;

import co.paralleluniverse.fibers.Suspendable;
import com.example.state.PayloadDeliveryState;
import net.corda.core.contracts.ContractState;
import net.corda.core.crypto.SecureHash;
import net.corda.core.flows.*;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.utilities.ProgressTracker;

import static net.corda.core.contracts.ContractsDSL.requireThat;


@InitiatedBy(SinglePayloadDelivery.class)
public class SinglePayloadDeliveryResponder extends FlowLogic<SignedTransaction> {

	private FlowSession counterpartySession;

	public SinglePayloadDeliveryResponder(FlowSession counterpartySession) {
		this.counterpartySession = counterpartySession;
	}

	@Suspendable
	@Override
	public SignedTransaction call() throws FlowException {

		class SignTxFlow extends SignTransactionFlow {

			private SignTxFlow(FlowSession initiatorFlow, ProgressTracker progressTracker) {
				super(initiatorFlow, progressTracker);
			}

			@Override
			protected void checkTransaction(SignedTransaction stx) {
				requireThat(require -> {
					ContractState output = stx.getTx().getOutputs().get(0).getData();
					require.using("This must be a PayloadDeliveryState transaction", output instanceof PayloadDeliveryState);
					Party notary = stx.getTx().getNotary();
					require.using("Notary must not be null", notary != null);
					return null;
				});
			}
		}

		System.out.println("SinglePayloadResponder------------");
		final SignTxFlow signTxFlow = new SignTxFlow(counterpartySession, SignTransactionFlow.Companion.tracker());
		final SecureHash txId = subFlow(signTxFlow).getId();
		final SignedTransaction transaction = subFlow(new ReceiveFinalityFlow(counterpartySession, txId));


		final PayloadDeliveryState outputState = (PayloadDeliveryState) transaction.getTx().getOutputs().get(0).getData();
		int newChainLength = outputState.getChainLength() - 1;

		System.out.println("New ChainLength: " + newChainLength);
		if (newChainLength > 0) {
			Party initiator = signTxFlow.getOurIdentity();
			Party receiverParty = counterpartySession.getCounterparty();
			subFlow(new SinglePayloadDelivery(initiator, receiverParty, outputState, txId));
		}
		System.out.println("PreviousTransaction: " + transaction.toString());

		return transaction;
	}

}
