package com.example.flow;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;

import com.example.contract.PayloadDeliveryContract;
import com.example.state.PayloadDeliveryState;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

import co.paralleluniverse.fibers.Suspendable;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.flows.CollectSignaturesFlow;
import net.corda.core.flows.FinalityFlow;
import net.corda.core.flows.FlowException;
import net.corda.core.flows.FlowLogic;
import net.corda.core.flows.FlowSession;
import net.corda.core.flows.InitiatingFlow;
import net.corda.core.flows.StartableByRPC;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.utilities.ProgressTracker;
import net.corda.core.utilities.ProgressTracker.Step;


@InitiatingFlow
@StartableByRPC
public class PayloadDelivery extends FlowLogic<SignedTransaction> {

	private Party receiver;
	private String payload;
	private Integer chainLength;
	private Boolean multiParty;

	private final Step INIT_TRANSACTION = new Step("Initializing the setup.");
	private final Step GENERATING_TRANSACTION = new Step("Generating transaction based on new PayloadDeliveryState.");
	private final Step VERIFYING_TRANSACTION = new Step("Verifying contract constraints.");
	private final Step SIGNING_TRANSACTION = new Step("Signing transaction with our private key.");
	private final Step GATHERING_SIGS = new Step("Gathering the counterparty's signature.") {
		@Override
		public ProgressTracker childProgressTracker() {
			return CollectSignaturesFlow.Companion.tracker();
		}
	};
	private final Step FINALISING_TRANSACTION = new Step("Obtaining notary signature and recording transaction.") {
		@Override
		public ProgressTracker childProgressTracker() {
			return FinalityFlow.Companion.tracker();
		}
	};

	private final ProgressTracker progressTracker = new ProgressTracker(
			INIT_TRANSACTION, GENERATING_TRANSACTION, VERIFYING_TRANSACTION, SIGNING_TRANSACTION,GATHERING_SIGS, FINALISING_TRANSACTION);

	public PayloadDelivery(Party receiver, String payload, Integer chainLength, Boolean multiParty) {
		super();
		this.receiver = receiver;
		this.payload = payload;
		this.chainLength = chainLength;
		this.multiParty = multiParty;
	}

	@Override
	public ProgressTracker getProgressTracker() {
		return progressTracker;
	}

	@Suspendable
	@Override
	public SignedTransaction call() throws FlowException {
		progressTracker.setCurrentStep(INIT_TRANSACTION);
		Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);
		Party initiator = getOurIdentity();
//		List<Party> receiverParties = new ArrayList<Party>();
//
//		//Split input to get receiver
//		String[] receiverNames = receiver.split(";");
//		for (String name : receiverNames){
//			String[] receiverNameParts = name.split(",?\\S=\\s*");
//			if (receiverNameParts.length == 4){
//				receiverParties.add(getServiceHub().getIdentityService().wellKnownPartyFromX500Name(new CordaX500Name(receiverNameParts[1], receiverNameParts[2], receiverNameParts[3])));
//			}
//		}
//		System.out.println("ReceiverNames: " + receiverNames.length);

		//Generate receiverSessions
		List<FlowSession> receiverSessions = new ArrayList<>();
		List<PublicKey> keys = new ArrayList<>();
		keys.add(initiator.getOwningKey());
		UniqueIdentifier uniqueIdentifier = new UniqueIdentifier();
		PayloadDeliveryState state = new PayloadDeliveryState(uniqueIdentifier, initiator, receiver, payload, chainLength, keys);
		keys.add(receiver.getOwningKey());
		//		for (Party receiverParty : receiverParties){
//			receiverSessions.add(initiateFlow(receiverParty));
//			keys.add(receiverParty.getOwningKey());
//		}
		System.out.println("Keys: " + keys.size());

		progressTracker.setCurrentStep(GENERATING_TRANSACTION);
		final Command<PayloadDeliveryContract.Commands.Create> txCommandPayloadDeliveryState = new Command<>(
				new PayloadDeliveryContract.Commands.Create(), ImmutableList.copyOf(keys));

		final TransactionBuilder txBuilder = new TransactionBuilder(notary);
		txBuilder.addOutputState(state, PayloadDeliveryContract.ID);
		txBuilder.addCommand(txCommandPayloadDeliveryState);

		progressTracker.setCurrentStep(VERIFYING_TRANSACTION);
		txBuilder.verify(getServiceHub());

		progressTracker.setCurrentStep(SIGNING_TRANSACTION);
		SignedTransaction partSignedTx = getServiceHub().signInitialTransaction(txBuilder);


		System.out.println("Number of receivers: " + receiverSessions.size());
		progressTracker.setCurrentStep(GATHERING_SIGS);
		final SignedTransaction fullySignedTx = subFlow(
				new CollectSignaturesFlow(partSignedTx, ImmutableSet.copyOf(receiverSessions), CollectSignaturesFlow.Companion.tracker()));

		progressTracker.setCurrentStep(FINALISING_TRANSACTION);
		return subFlow(new FinalityFlow(fullySignedTx, ImmutableSet.copyOf(receiverSessions)));
	}

}
