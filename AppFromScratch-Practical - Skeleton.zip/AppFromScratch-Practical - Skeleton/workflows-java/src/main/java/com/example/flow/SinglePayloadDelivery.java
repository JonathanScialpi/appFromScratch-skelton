package com.example.flow;

import co.paralleluniverse.fibers.Suspendable;
import com.example.contract.PayloadDeliveryContract;
import com.example.state.PayloadDeliveryState;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import net.corda.core.contracts.*;
import net.corda.core.crypto.SecureHash;
import net.corda.core.flows.*;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.utilities.ProgressTracker;

import java.security.PublicKey;
import java.util.List;

import static net.corda.core.contracts.ContractsDSL.requireThat;

@InitiatingFlow
public class SinglePayloadDelivery extends FlowLogic<SignedTransaction> {

	private Party initiator;
	private Party receiver;
	private PayloadDeliveryState previousState;
	private SecureHash prevTxId;

	public SinglePayloadDelivery(Party initiator, Party receiver, PayloadDeliveryState previousState, SecureHash prevTxId) {
		this.initiator = initiator;
		this.receiver = receiver;
		this.previousState = previousState;
		this.prevTxId = prevTxId;
	}

	@Suspendable
	@Override
	public SignedTransaction call() throws FlowException {

		class SignTxFlow extends SignTransactionFlow {

			private SignTxFlow(FlowSession initiatorFlow, ProgressTracker progressTracker) {
				super(initiatorFlow, progressTracker);
			}

			@Override
			protected void checkTransaction(SignedTransaction stx) {
				requireThat(require -> {
					ContractState output = stx.getTx().getOutputs().get(0).getData();
					require.using("This must be a PayloadDeliveryState transaction", output instanceof PayloadDeliveryState);
					Party notary = stx.getTx().getNotary();
					require.using("Notary must not be null", notary != null);
					return null;
				});
			}
		}


		System.out.println("SinglePayloadDelivery------------");
		int newChainLength = previousState.getChainLength() - 1;
		List<PublicKey> keys = previousState.getKeys();
		String payload = previousState.getPayload();
		UniqueIdentifier linearId = previousState.getLinearId();
		PayloadDeliveryState outputState = new PayloadDeliveryState(linearId, initiator, receiver, payload, newChainLength, keys);
		FlowSession receiverSession = initiateFlow(receiver);

		final Command<PayloadDeliveryContract.Commands.Create> txCommandPayloadDeliveryState = new Command<>(
				new PayloadDeliveryContract.Commands.Create(), ImmutableList.copyOf(keys));


		final StateRef stateRef = new StateRef(prevTxId, 0);
		StateAndRef stateAndRef = getServiceHub().toStateAndRef(stateRef);

		Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);
		final TransactionBuilder txBuilder = new TransactionBuilder(notary);
		txBuilder.addInputState(stateAndRef);
		txBuilder.addOutputState(outputState, PayloadDeliveryContract.ID);
		txBuilder.addCommand(txCommandPayloadDeliveryState);
		txBuilder.verify(getServiceHub());


		System.out.println("Start SinglePayload with outputState: " + outputState.toString());
		SignedTransaction partSignedTx = getServiceHub().signInitialTransaction(txBuilder);

		final SignedTransaction fullySignedTx = subFlow(
				new CollectSignaturesFlow(partSignedTx, ImmutableSet.of(receiverSession), CollectSignaturesFlow.Companion.tracker()));

		return subFlow(new FinalityFlow(fullySignedTx, ImmutableSet.of(receiverSession)));
	}

}
