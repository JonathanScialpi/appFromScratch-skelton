package com.example.test.flow;


import com.example.flow.IOUFlow;
import com.example.state.IOUState;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import net.corda.core.concurrent.CordaFuture;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.TransactionState;
import net.corda.core.contracts.TransactionVerificationException;
import net.corda.core.transactions.SignedTransaction;
import net.corda.testing.node.MockNetwork;
import net.corda.testing.node.MockNetworkParameters;
import net.corda.testing.node.StartedMockNode;
import net.corda.testing.node.TestCordapp;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.util.List;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.assertEquals;

public class IOUFlowTests {
    private MockNetwork network;
    private StartedMockNode a;
    private StartedMockNode b;

    @Before
    public void setup() {
        network = new MockNetwork(new MockNetworkParameters().withCordappsForAllNodes(ImmutableList.of(
                TestCordapp.findCordapp("com.example.contract"),
                TestCordapp.findCordapp("com.example.flow"))));
        a = network.createPartyNode(null);
        b = network.createPartyNode(null);
        // For real nodes this happens automatically, but we have to manually register the flow for tests.
        for (StartedMockNode node : ImmutableList.of(a, b)) {
            node.registerInitiatedFlow(IOUFlow.Acceptor.class);
        }
        network.runNetwork();
    }

    @After
    public void tearDown() {
        network.stopNodes();
    }

    @Rule
    public final ExpectedException exception = ExpectedException.none();

    @Test
    public void flowRejectsInvalidIOUs() throws Exception {
        // The IOUContract specifies that IOUs cannot have negative values.
        IOUFlow.Initiator flow = new IOUFlow.Initiator(-1, b.getInfo().getLegalIdentities().get(0));
        CordaFuture<SignedTransaction> future = a.startFlow(flow);
        network.runNetwork();

        // The IOUContract specifies that IOUs cannot have negative values.
        exception.expectCause(instanceOf(TransactionVerificationException.class));
        future.get();
    }

    /** TO COMPLETE: signedTransactionReturnedByTheFlowIsSignedByTheInitiator()
     *  Hint: Call verifySignaturesExcept(PublicKey) on the result returned from the future. */
    @Test
    public void signedTransactionReturnedByTheFlowIsSignedByTheInitiator() throws Exception {

    }

    /** TO COMPLETE: signedTransactionReturnedByTheFlowIsSignedByTheAcceptor() */
    @Test
    public void signedTransactionReturnedByTheFlowIsSignedByTheAcceptor() throws Exception {

    }

    /** TO COMPLETE: flowRecordsATransactionInBothPartiesTransactionStorages()
     *  Hint: Query each node's vault and verify they are storing the same transaction that is returned from the future.
     *  Hint: Use assert() or assertEquals() */
    @Test
    public void flowRecordsATransactionInBothPartiesTransactionStorages() throws Exception {

    }

    /** TO COMPLETE: recordedTransactionHasNoInputsAndASingleOutputTheInputIOU()
     *  Hint: Get the recorded transaction, assert there are no input states and a single output state. */
    @Test
    public void recordedTransactionHasNoInputsAndASingleOutputTheInputIOU() throws Exception {

    }

    /** TO COMPLETE: flowRecordsTheCorrectIOUInBothPartiesVaults()
     *  Hint: Get the IOUState from both nodes are verify that it has the correct values. */
    @Test
    public void flowRecordsTheCorrectIOUInBothPartiesVaults() throws Exception {

    }
}