package org.acmecorp.flows.test;

import com.google.common.collect.ImmutableList;
import net.corda.core.concurrent.CordaFuture;
import net.corda.core.contracts.Amount;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.identity.Party;
import net.corda.core.node.services.VaultService;
import net.corda.core.transactions.SignedTransaction;
import net.corda.testing.common.internal.ParametersUtilitiesKt;
import net.corda.testing.node.*;
import org.acmecorp.flows.RegistrationFlow;
import org.acmecorp.state.Address;
import org.acmecorp.state.CustomerState;
import org.acmecorp.state.PropertyType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Currency;
import java.util.List;
import java.util.concurrent.ExecutionException;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CustomerFlowTests {

    private MockNetwork network;
    private StartedMockNode a;
    private StartedMockNode b;

    static Amount<Currency> defaultPropValuation = new Amount<Currency>((long) 100000, Currency.getInstance("USD"));
    static Amount<Currency> defaultBuyerRangeFrom = new Amount<Currency>((long) 90000, Currency.getInstance("USD"));
    static Amount<Currency> defaultBuyerRangeTo = new Amount<Currency>((long) 120000, Currency.getInstance("USD"));
    static Address defaultPropAdd1 = new Address("1 Property Street");
    static Address defaultBuyerAdd1 = new Address("1 Buyer Street");

    static PropertyType propTypeDef1= new PropertyType(defaultPropAdd1, defaultPropValuation);
    static List<PropertyType> defaultProperties = Arrays.asList(propTypeDef1);

    static int MIN_BEDROOMS = 3;
    static int MAX_BEDROOMS = 6;
    static String PCODE_AREA = "90210";

    @Before
    public void setup() {
        network = new MockNetwork(
                new MockNetworkParameters()
                        .withCordappsForAllNodes(ImmutableList.of(
                                TestCordapp.findCordapp("com.r3.corda.lib.tokens.contracts"),
                                TestCordapp.findCordapp("com.r3.corda.lib.tokens.workflows"),
                                TestCordapp.findCordapp("org.acmecorp.flows"),
                                TestCordapp.findCordapp("org.acmecorp.contract")

                                ))
                        .withNetworkParameters(ParametersUtilitiesKt.testNetworkParameters(
                                Collections.emptyList(), 4
                        ))
        );
        a = network.createPartyNode(null);
        b = network.createPartyNode(null);
        network.runNetwork();





    }

    @After
    public void tearDown() {
        network.stopNodes();
    }

    @Test
    public void RegisterCustomerState() throws ExecutionException, InterruptedException {

        Party partyB = b.getInfo().getLegalIdentities().get(0);
        CustomerState.CustomerStatus customerStatus = CustomerState.CustomerStatus.REGISTERED;
        RegistrationFlow.RegisterWithAgent registerWithAgentFlow = new RegistrationFlow.RegisterWithAgent(
                propTypeDef1,
                partyB,
                customerStatus,
                defaultBuyerAdd1,
                defaultBuyerRangeFrom,
                defaultBuyerRangeTo,
                1,
                4,
                "90210");


        CordaFuture<SignedTransaction> future = a.startFlow(registerWithAgentFlow);
        network.runNetwork();
        SignedTransaction signedTx = future.get();
        assertNotNull(signedTx);

    }
}
