//package org.acmecorp.flows;
//
//import co.paralleluniverse.fibers.Suspendable;
//
//import com.google.common.collect.ImmutableList;
//import net.corda.core.contracts.Amount;
//import net.corda.core.contracts.Command;
//import net.corda.core.flows.*;
//import net.corda.core.identity.Party;
//import net.corda.core.transactions.SignedTransaction;
//import net.corda.core.transactions.TransactionBuilder;
//import org.acmecorp.contract.CustomerContract;
//import org.acmecorp.state.Address;
//import org.acmecorp.state.CustomerState;
//import org.acmecorp.state.PropertyType;
//
//import java.util.Arrays;
//
//
//public class RegistrationFlow {
//    @InitiatingFlow
//    @StartableByRPC
//    public static class RegisterWithAgent extends FlowLogic<SignedTransaction> {
//
//        private final PropertyType prop;
//        private final Party agent;
//        private final CustomerState.CustomerStatus customerStatus;
//        private final Address address;
//        private final Amount rangeFrom;
//        private final Amount rangeTo;
//        private final int minBedrooms;
//        private final int maxBedrooms;
//        private final String postCodeArea;
//
//        public RegisterWithAgent(PropertyType prop, Party agent, CustomerState.CustomerStatus customerStatus, Address address, Amount rangeFrom, Amount rangeTo, int minBedrooms, int maxBedrooms, String postCodeArea) {
//            this.prop = prop;
//            this.agent = agent;
//            this.customerStatus = customerStatus;
//            this.address = address;
//            this.rangeFrom = rangeFrom;
//            this.rangeTo = rangeTo;
//            this.minBedrooms = minBedrooms;
//            this.maxBedrooms = maxBedrooms;
//            this.postCodeArea = postCodeArea;
//        }
//
//
//        /**
//         * The flow logic is encapsulated within the call() method.
//         */
//        @Suspendable
//        @Override
//        public SignedTransaction call() throws FlowException {
//            // Obtain a reference to the notary we want to use.
//            final Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0);
//
//            // Stage 1.
//            // Generate an unsigned transaction.
//            Party me = getOurIdentity();
//
//            CustomerState customerState = new CustomerState(customerStatus,
//                    Arrays.asList(prop),
//                    me,
//                    agent,
//                    address,
//                    rangeFrom,
//                    rangeTo,
//                    minBedrooms,
//                    maxBedrooms,
//                    postCodeArea,
//                    0,
//                    "");
//
//            final Command<CustomerContract.Commands.Register> txCommand = new Command(
//                    new CustomerContract.Commands.Register(),
//                    ImmutableList.of(me.getOwningKey(), agent.getOwningKey()));
//            final TransactionBuilder txBuilder = new TransactionBuilder(notary)
//                    .addOutputState(customerState, CustomerContract.CUSTOMER_CONTRACT_ID)
//                    .addCommand(txCommand);
//
//            // Stage 2.
//            // Verify that the transaction is valid.
//            txBuilder.verify(getServiceHub());
//
//            // Stage 3.
//            // Sign the transaction.
//            final SignedTransaction partSignedTx = getServiceHub().signInitialTransaction(txBuilder);
//
//            return partSignedTx;
//        }
//    }
//    @InitiatedBy(RegisterWithAgent.class)
//    public static class Acceptor extends FlowLogic<SignedTransaction> {
//        private final FlowSession otherPartySession;
//        public Acceptor(FlowSession otherPartySession) {
//            this.otherPartySession = otherPartySession;
//        }
//        @Override
//        public SignedTransaction call() throws FlowException {
//            return null;
//        }
//    }
//
//}
